const API_BASE_URL = 'https://ytskn1hvff.execute-api.us-east-1.amazonaws.com/backend';

export default API_BASE_URL;
